module.exports = function (nosql) {

    nosql.model('DevBug', new nosql.Schema({
        user_id: { type: nosql.Schema.Types.ObjectId, ref: 'Account', default: null },
        title: { type: String, default: '' },
        description: String,
        status: {
            type: String,
            enum: ['Open', 'In Progress', 'Closed'],
            default: 'Open'
        },
        is_deleted: { type: Boolean, default: false },
        createdAt: { type: Date, default: Date.now }
    }));


 nosql.model('RegisterUser', new nosql.Schema({
        name: {
            type: String,
            required: true
        },
        email: {
            type: String,
            required: true
        },
        password: {
            type: String,
            required: true
        },
        contact: {
            type: Number,
            required: true
        },
        gender: {
            type: String, 
        },
        is_deleted: { type: Boolean, default: false }, 
        createdAt: { type: Date, default: Date.now }
    }));

};

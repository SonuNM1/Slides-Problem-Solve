
const RegisterUser = require("../bootstrap/models")

var pageControllers = {}

const loginPage =(req,res)=>{
  res.render("login")
}

const signupPage = (req, res)=>{
  res.render("signup")
}

const signupData = async (req, res) =>{
  const data = {
    name : req.body.name , 
    password : req.body.password,
    email: req.body.email , 
    contact: req.body.contact ,
    gender: req.body.gender
  }
  var registeruser = nosql.model("RegisterUser")
  var results  = await registeruser.insertMany([data])
  res.render("home",{results:results})
}

const loginData = async (req, res)=>{
  try{
    var registeruser = nosql.model("RegisterUser")
    const check = await registeruser.findOne({name: req.body.name})

    if(check.password === req.body.password){
      res.render("home")
    } 
    else {
      res.send("wrong password")
    }
  }
  catch{
    res.send("wrong details")
  }
}
 
pageControllers.loginPage = loginPage ;
pageControllers.signupPage = signupPage ;
pageControllers.signupData = signupData ; 
pageControllers.loginData = loginData ; 

module.exports = pageControllers;
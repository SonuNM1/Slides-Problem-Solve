const bugService = require("../app_modules/bugService");
const bugController = {};

const FetchAll = async (req, res) => {
    if (req.query.type == "json") {
        const data = await bugService.ShowTable(req.query);
        res.status(200).json(data);
    }
    else {
        res.render('bug/bug', { title: "Bugs" });
    }
}

const Create = async (req, res) => {
    try {
        const data = {
            user_id: "657fd852c3d7982e7535e030",
            title: req.body.title,
            description: req.body.description,
        }
        const result = await bugService.saveData(data);
        if (result.status && result.id !== "") return res.status(201).json({ message: "New bug created successfully." });
        throw new Error("Unable to create new bug.");
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

const Edit = async (req, res) => {
    const _id = req.body.bug_id;
    try {
        const result = await bugService.updateData(_id, req.body);
        if (result) return res.status(202).json({ message: "Bug updated" });
        throw new Error("Unable to update")
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

const Delete = async (req, res) => {
    const _id = req.body.bug_id;
    try {
        const result = await bugService.deleteData(_id);
        if (result) return res.status(200).json({ message: "Bug deleted successfully." })
        throw new Error("Unable to delete");
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

bugController.FetchAll = FetchAll;
bugController.Create = Create;
bugController.Edit = Edit;
bugController.Delete = Delete;
module.exports = bugController;

const bugService = {};
const ShowTable = async (query) => {
    const { start, length, draw, search } = query;
    var Bug = nosql.model('DevBug');
    const totalDocs = await Bug.countDocuments({is_deleted : false});
    const data = await Bug.find({
        is_deleted : false,
        "$or": [
            { title: { '$regex': `.*${search.value}.*`, '$options': 'i' } },
        ]
    }).skip(start).limit(length);
    return {
        draw,
        recordsTotal: totalDocs,
        recordsFiltered: totalDocs,
        data
    }
};

const saveData = async (data) => {
    try {
        var Bug = nosql.model('DevBug');
        const bug = await Bug(data).save();
        if (bug._id !== "") return { status: true, id: bug._id };
    } catch (error) {
        return { status: false }
    }
}

const updateData = async (_id, data) => {
    var Bug = nosql.model('DevBug');
    const { modifiedCount } = await Bug.updateOne({ _id }, data);
    return modifiedCount;
}

const deleteData = async (_id) => {
    var Bug = nosql.model('DevBug');
    const { modifiedCount } = await Bug.updateOne({ _id },{$set : {is_deleted : true }});
    return modifiedCount;
}

bugService.ShowTable = ShowTable;
bugService.saveData = saveData;
bugService.updateData = updateData;
bugService.deleteData = deleteData;
module.exports = bugService;
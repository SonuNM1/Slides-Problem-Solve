define(['jquery',"toastr",'datatable',], function ($,toastr) {
    load_css('datatable');
    load_css("jqueryDataTable");
    $(document).ready(function () {
       
        const table = $('#bugsTable').DataTable({
            'ordering': false,
            'processing': true,
            'serverSide': true,
            'serverMethod': 'get',
            'ajax': {
                'url': '/dev_bug?type=json'
            },
            'columns': [
                { data: 'title' },
                { data: 'description' },
                {
                    data: function (row) {
                        if (row.status == "Open")
                            return `<span class="badge bg-success">${row.status}</span>`;
                        else if (row.status == "In Progress")
                            return `<span class="badge bg-warning">${row.status}</span>`;
                        else return `<span class="badge bg-danger">${row.status}</span>`;
                    }
                },
                {
                    data: function (row) {
                        return new Date(row.createdAt).toDateString();
                    }
                },
                {
                    data: function (row) {
                        return `<button data-row='${JSON.stringify(row)}' class="btn btn-sm btn-primary editBtn">Edit</button>
                  <button   data-id="${row._id}" class="btn btn-sm btn-danger deleteBtn">Delete</button>`
                    }
                }
            ]
        });

        $("#createBugForm").submit(function (e) {
            e.preventDefault();
            const form = $(this);
            $.ajax({
                type: "POST",
                url: $(this).attr("action"),
                data: $(this).serialize(),
                success: function (res) {
                    toastr.success(res.message)
                    $("#exampleModal").modal("hide");
                    $(form).trigger("reset");
                    table.ajax.reload();
                },
                error: function (xhr) {
                    toastr.error(xhr.responseJSON.message);
                }
            });
        });

        $(document).on("click", ".deleteBtn", function (e) {
            e.preventDefault();
            const bug_id = $(this).data("id");
            if (confirm("Are you sure to delete this bug?")) {
                $.ajax({
                    method: "POST",
                    url: "/dev_bug/delete",
                    data: { bug_id },
                    success: function (res) {
                        toastr.success(res.message);
                        table.ajax.reload();
                    },
                    error: function (xhr) {
                        toastr.error(xhr.responseJSON.message);
                    }
                })
            }
        });

        $(document).on("click", ".editBtn", function () {
            const data = $(this).data("row");
            $("#title").val(data.title);
            $("#description").val(data.description);
            $("#editBugForm").attr("action", "/dev_bug/edit")
            $("#hidden_field").html(`<input type="hidden" name="bug_id" value="${data._id}" />`);
            $("#status option").each(function (index, element) {
                if ($(element).val() == data.status) {
                    $(element).attr("selected", "selected");
                }
            })
            $("#editModal").modal("show");
        });

        $("#editBugForm").submit(function (e) {
            e.preventDefault();
            const form = $(this);
            $.ajax({
                type: "POST",
                url: $(this).attr("action"),
                data: $(this).serialize(),
                success: function (res) {
                    toastr.success(res.message);
                    $("#editModal").modal("hide");
                    $(form).trigger("reset");
                    table.ajax.reload();
                },
                error: function (xhr) {
                    toastr.error(xhr.responseJSON.message);
                }
            });
        });
    });
});